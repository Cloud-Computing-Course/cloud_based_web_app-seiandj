var account = {

    name: "",
    email: "",
    password: "",

}

exports.account;